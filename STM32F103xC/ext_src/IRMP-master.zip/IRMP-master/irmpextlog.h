#ifndef _IRMPEXTLOG_H
#define _IRMPEXTLOG_H

#ifdef __cplusplus
extern "C"
{
#endif

void    initextlog (void);
void    sendextlog (unsigned char);

#ifdef __cplusplus
}
#endif

#endif
