IRMP - Infrared Multi Protocol Decoder
--------------------------------------

Version IRMP:  3.2.6.7 2022-07-14
Version IRSND: 3.2.6.6 2022-02-08

Documentation:
 
   http://www.mikrocontroller.net/articles/IRMP
   http://www.mikrocontroller.net/articles/IRMP_-_english

   http://www.mikrocontroller.net/articles/IRSND
   http://www.mikrocontroller.net/articles/IRSND_-_english
